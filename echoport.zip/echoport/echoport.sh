#!/bin/bash
java -jar echoport.jar $1
